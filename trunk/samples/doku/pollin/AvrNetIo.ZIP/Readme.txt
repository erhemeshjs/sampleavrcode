Bitte lesen Sie die folgenden Bestimmungen sorf�ltig durch.
Wenn Sie mit irgendeiner Bestimmung dieser Vereinbarung nicht einverstanden sind, d�rfen Sie das Programm NetServer nicht installieren, benutzen, vervielf�ltigen oder weitergeben.

1. Nutzungsrecht
NetServer ist Freeware.
Das bedeutet, die Software darf in unver�nderter Form zusammen mit dieser Vereinbarung frei kopiert, unentgeltlich weitergegeben und genutzt werden.
Es ist Ihnen nicht gestattet die Software ganz oder teilweise zu �ndern, zu modifizieren oder zu dekompilieren.
Weiterhin ist es Ihnen nicht gestattet Copyrightvermerke, Eigentumsangaben des Herstellers und Kennzeichen des Herstellers an der Software oder der Dokumentation zu ver�ndern.
Der Einsatz der Software in Anwendungen und auf Systemen, in denen Fehlfunktionen dieser Software nach menschlichem Ermessen und unter Ber�cksichtigung aller Umst�nde und Bedingungen auftreten k�nnen, ist ausdr�cklich untersagt.

2. Gew�hrleistung/Haftung
Es k�nnen Fehlfunktionen auch bei ausf�hrlich getesteter Software durch die Vielzahl an verschiedenen Rechnerkonfigurationen niemals ausgeschlossen werden.
Da die Software kostenlos ist, ist diese lediglich als Testsoftware einzusetzen, daher wird keinerlei Gew�hrleistung f�r die gesamte Nutzung der Software �bernommen. F�r durch den Einsatz der Software an anderer Software oder an Datentr�gern/Datenverarbeitungsanlagen entstandene Sch�den wird nur dann gehaftet, wenn es sich beim schadensurs�chlichen Mangel um Vorsatz oder grobe Fahrl�ssigkeit durch einen gesetzlichen Vertreter oder Erf�llungsgehilfen und einen vorhersehbaren, typischerweise auftretenden Schaden handelt. Es wird empfohlen auf dem betreffendem System, auf dem die Software zum Einsatz kommt, eine entsprechende Datensicherung durchzuf�hren. Die Software ist nicht f�r den industriellen oder Produktiveinsatz gedacht.

**************************************************************************
***************************** WICHTIG ************************************
**************************************************************************

Das Programm NetServer ben�tigt zum fehlerfreien Betrieb das
.NET-Framework v2.0.

Dieses (dotnetfx.exe) kann von http://www.microsoft.de kostenfrei
heruntergeladen werden.

**************************************************************************
***************************** WICHTIG ************************************
**************************************************************************